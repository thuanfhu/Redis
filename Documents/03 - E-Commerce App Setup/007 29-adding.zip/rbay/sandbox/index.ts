import 'dotenv/config';
import { client } from '../src/services/redis';

const run = async () => {};
run();
