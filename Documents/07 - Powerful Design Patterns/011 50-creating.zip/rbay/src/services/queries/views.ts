export const incrementView = async (itemId: string, userId: string) => {};
